package com.iotprojectmanagmentforuniversity;

public class OpenExcel {
	
	public String  firstName,lastName,email,dateofBirth;
	public OpenExcel(String firstname, String lastname,String email,String dateofBirth) {
		this.firstName=firstname;
		this.lastName=lastname;
		this.email=email;
		this.dateofBirth=dateofBirth;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
	}

}
 